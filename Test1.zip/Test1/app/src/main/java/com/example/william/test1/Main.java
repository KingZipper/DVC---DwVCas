package com.example.william.test1;

public class Main {


    public static void main (String[] args) {
        App app = new App();
        System.out.println("Good day! Now the application is loading..");
        app.initializing();
    }

}
